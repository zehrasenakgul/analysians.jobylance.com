// const Analysians_Informations = [{
//     Analysian_Username : "Kripto Ege",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda ilk karatker"
// },
// {
//     Analysian_Username : "Kripto Berkay",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 2 karatker"
// },
// {
//     Analysian_Username : "Kripto Yusufhan",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 3 karatker"
// },
// {
//     Analysian_Username : "Kripto Baris",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 4 karatker"
// },
// {
//     Analysian_Username : "Kripto Ece",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 5 karatker"
// },
// {
//     Analysian_Username : "Kripto Efe",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 6 karatker"
// },
// {
//     Analysian_Username : "Kripto Emel",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 7 karatker"
// },
// {
//     Analysian_Username : "Kripto Berk",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 8 karatker"
// },
// {
//     Analysian_Username : "Kriptoman",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 9 karatker"
// },
// {
//     Analysian_Username : "Kripto Barista",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 10 karatker"
// },
// {
//     Analysian_Username : "Kripto Ecem",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 11 karatker"
// },
// {
//     Analysian_Username : "Kripto Efekan",
//     Analysian_Biography : "Biyografisini yediğimin analysianlarinin demosunda 12 karatker"
// },
// ]

const list_items = [
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
	'<img src="./assets/media/AnalysianProfilePicture.png" alt="" class="AnalysianProfilePicture"> <img src="./assets/media/CardFrameBtm.svg" id="CardFrame" alt=""> <div class="AnalysianCard-Textbox"> <span class="Analysian_Username">Kripto Erkan</span> <p class="Analysian_Bio">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quia ipsam itaque molestias natus in odit minima, dolores adipisci necessitatibus magni sit corrupti illo sequi repellendus maxime labore deserunt quaerat.</p></div><button id="ProfileGitButton">Profili Gör</button><div class="AnalysianCard-Socials"><a href="" id="Analysian_Twitter_Link"><img src="./assets/media/Twitter Icon.png" alt=""></a><a href="www.google.com" id="Analysian_Instagram_Link"><img src="./assets/media/Instagram Icon.png" alt=""></a></div>',
]

const list_element = document.getElementById('AnalysiansCards');
const pagination_element = document.getElementById('Pagination');

let current_page = 1;
let item_count = 6;

if (screen.height < 900) { 
	item_count = 3;
}

function DisplayList (items, wrapper, rows_per_page, page) {
	wrapper.innerHTML = "";
	page--;

	let start = rows_per_page * page;
	let end = start + rows_per_page;
	let paginatedItems = items.slice(start, end);

	for (let i = 0; i < paginatedItems.length; i++) {
		let item = paginatedItems[i];

		let item_element = document.createElement('div');
		item_element.classList.add('AnalysianCard');
		item_element.innerHTML = item;
		
		wrapper.appendChild(item_element);
	}
}

function SetupPagination (items, wrapper, rows_per_page) {
	wrapper.innerHTML = "";

	let page_count = Math.ceil(items.length / rows_per_page);
	if (screen.width < 600) {
		document.querySelector(".Pagination").style.justifyContent = "unset"
		console.log("hey")
	}
	for (let i = 1; i < page_count + 1; i++) {
		let btn = PaginationButton(i, items);
		wrapper.appendChild(btn);
	}
}

function PaginationButton (page, items) {
	let button = document.createElement('button');
    button.className = "PageNumber";  
	button.innerText = page;

	if (current_page == page) button.classList.add('activeButton');

	button.addEventListener('click', function () {
		current_page = page;
		DisplayList(items, list_element, item_count, current_page);

		let current_btn = document.querySelector('.Pagination button.activeButton');
		current_btn.classList.remove('activeButton');

		button.classList.add('activeButton');
	});

	return button;
}

DisplayList(list_items, list_element, item_count, current_page);
SetupPagination(list_items, pagination_element, item_count);