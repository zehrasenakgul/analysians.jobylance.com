/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'fa', {
	alt: 'متن جایگزین',
	btnUpload: 'به سرور بفرست',
	captioned: 'تصویر زیرنویس شده',
	captionPlaceholder: 'عنوان',
	infoTab: 'اطلاعات تصویر',
	lockRatio: 'قفل کردن نسبت',
	menu: 'ویژگی​های تصویر',
	pathName: 'تصویر',
	pathNameCaption: 'عنوان',
	resetSize: 'بازنشانی اندازه',
	resizer: 'کلیک و کشیدن برای تغییر اندازه',
	title: 'ویژگی​های تصویر',
	uploadTab: 'بالاگذاری',
	urlMissing: 'آدرس URL اصلی تصویر یافت نشد.',
	altMissing: 'متن جایگزین یافت نشد.'
} );
