/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'lv', {
	pathName: 'mēdija objekts',
	title: 'Ievietot mēdiju',
	button: 'ievietot mēdija objektu',
	unsupportedUrlGiven: 'Norādītā adrese netiek atbalstīta',
	unsupportedUrl: 'Adrese {url} netiek atblastīta ievietošanai.',
	fetchingFailedGiven: 'Neizdevās ielādēt saturu no norādītās adreses.',
	fetchingFailed: 'Neizdevās ielādēt saturu no {url}',
	fetchingOne: 'Ielādēju oEmbed atbildi...',
	fetchingMany: 'Ielādēju oEmbed atbildes, {current} no {max} izpildīts...'
} );
