/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'ar', {
	pathName: 'media object',
	title: 'أرفق ميديا',
	button: 'أرفق ميديا',
	unsupportedUrlGiven: 'لم يتم العثور على الرابط المحدد.',
	unsupportedUrl: 'لم يتم العثور على الرابط {url}.',
	fetchingFailedGiven: 'فشل في جلب محتوى لعنوان URL.',
	fetchingFailed: 'فشل في جلب محتوى لعنوان {url}.',
	fetchingOne: 'جارٍ إحضار الاستجابة من oEmbed ...',
	fetchingMany: 'جار جلب الردود، {current} من {max} تم.'
} );
