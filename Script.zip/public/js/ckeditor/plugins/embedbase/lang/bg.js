/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'bg', {
	pathName: 'медиен обект',
	title: 'Вграждане на медия',
	button: 'Вмъкни медия',
	unsupportedUrlGiven: 'Посоченият URL адрес не се поддържа.',
	unsupportedUrl: 'URL адресът {url} не се поддържа от вграждането на медия.',
	fetchingFailedGiven: 'Извличането на съдържание за дадения URL адрес не е успешно.',
	fetchingFailed: 'Извличането на съдържание за {url} не е успешно.',
	fetchingOne: 'Извличане oEmbed заявка...',
	fetchingMany: 'Извличане oEmbed заявка, {current} от {max}...'
} );
